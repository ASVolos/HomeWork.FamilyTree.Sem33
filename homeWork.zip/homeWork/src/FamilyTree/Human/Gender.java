package FamilyTree.Human;

public enum Gender {
    male, female
}
